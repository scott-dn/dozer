### Data Processor

#### Pre Requisites
Install Rust
```
curl https://sh.rustup.rs -sSf | sh
```

#### Running Application
```
cargo run src/main.rs
```


### Sample Output
```
processed 100 records
processed 200 records
processed 300 records
processed 400 records
....
```